/******************************************************************
 * Header file for the helper functions. This file includes the
 * required header files, as well as the function signatures and
 * the semaphore values (which are to be changed as needed).
 ******************************************************************/


# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/ipc.h>
# include <sys/shm.h>
# include <sys/sem.h>
# include <sys/time.h>
# include <math.h>
# include <errno.h>
# include <string.h>
# include <pthread.h>
# include <ctype.h>
# include <iostream>
# include <signal.h>
using namespace std;

# define SEM_KEY 0x3718 // Change this number as needed

union semun {
    int val;               /* used for SETVAL only */
    struct semid_ds *buf;  /* used for IPC_STAT and IPC_SET */
    ushort *array;         /* used for GETALL and SETALL */
};

void thread_error_handler (const int &id, const int &sem, string type);
void main_error_handler (const int i, string type);
void sem_error_handler (const int sem, string func);
int check_arg (char *);
int sem_create (key_t, int);
int sem_init (int, int, int);
void sem_wait (int sem, int id, short unsigned int, string type = __builtin_FUNCTION());
void sem_wait (int sem, int id, short unsigned int, int, string type = __builtin_FUNCTION());
void sem_signal (int sem, int id, short unsigned int, string type = __builtin_FUNCTION());
int sem_close (int);
